# ----------------------------------------------------------------------------
# Program: MlengelaSocketServer
# Programmer: Daudi Mlengela (dnlengela@cnm.edu)(mlengelad@gmail.com)
# Instructor: Thomas Gitierrez (tgutierrez@cnm.edu)
# Date: Decmeber 10th, 2022
# Purpose: Building a simple Client-Sever application, understanding basic
# sockets programming in python
# ----------------------------------------------------------------------------


import socket #Included by default in Python

s = socket.socket() #Create socket object
host = socket.gethostname() #Grab hostname
#print(host)
port = 1234

# 192.168.1.100
# port 80, http, or port 443 for secure, https
# 192.168.1.100:80 - socketed IP address for HTTP, combines both IP address and port
s.bind((host,port)) #Create a socket by binding our host and port to our socket object. Note the double parens as bind() has a parameter of a tuple

#Listen on socketed address
s.listen(5) #5 represents the interval we'll listen
while True:
    c, addr = s.accept()
    print("Got a connection from", addr) #addr represents the requests originating IP Address
    print(c.recv(1024).decode()) #c represents what is being sent as bytes, most set a buffer size (1024), and must decode
    c.send(('Thank you for connecting').encode()) #Send a message back to connecting address, this can be anything, but should be encoded
    c.close()
