# ----------------------------------------------------------------------------
# Program: MlengelaSocketClient
# Programmer: Daudi Mlengela (dnlengela@cnm.edu)(mlengelad@gmail.com)
# Instructor: Thomas Gitierrez (tgutierrez@cnm.edu)
# Date: Decmeber 10th, 2022
# Purpose: Building a simple Client-Sever application, understanding the basic
# sockets programming in python
# ----------------------------------------------------------------------------
import socket

host = socket.gethostname()
port = 1234

data = "Hello Server!!"
count = 0
while count < 5:
    s = socket.socket()
    s.connect((host,port))
    s.send(data.encode())
    print(s.recv(1024).decode())
    s.close()
    count +=1
